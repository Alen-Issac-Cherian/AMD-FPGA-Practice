set_false_path -from [get_cells CTRL_s_axi_U/int_width_reg[*]]
set_false_path -from [get_cells CTRL_s_axi_U/int_height_reg[*]]
